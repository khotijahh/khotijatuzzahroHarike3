package com.example.khotijatuzzahroharike3

data class PerpusData(
    var id : String,
    var namaBuku : String,
    var jenisBk : String
)
